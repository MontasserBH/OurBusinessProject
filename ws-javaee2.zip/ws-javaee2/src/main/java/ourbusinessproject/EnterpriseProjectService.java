package ourbusinessproject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Created by Franck on 20/10/2017.
 */
@Service
public class EnterpriseProjectService {

    @Autowired
    private EntityManager entityManager;




    public void save(Project project)
    {
        if (project == null)
        {
            throw new IllegalArgumentException("Project must not be null");
        }
        if (project.getEnterprise() != null)
        {
            project.getEnterprise().addProject(project);
            save(project.getEnterprise());
        }
        entityManager.persist(project);
    }

    public void save(Enterprise enterprise)
    {
        if (enterprise == null)
        {
            throw new IllegalArgumentException("Enterprise must not be null");
        }
        entityManager.persist(enterprise);
    }

    public Project findProjectById(Long anId)
    {
        return entityManager.find(Project.class, anId);
    }

    public Enterprise findEnterpriseById(Long anId)
    {
        return entityManager.find(Enterprise.class, anId);
    }

    public EntityManager getEntityManager() {
        return entityManager;
    }

    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }


    public List<Project> findAllProjects() {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Project> cq = cb.createQuery(Project.class);
        Root<Project> projectRoot = cq.from(Project.class);
        CriteriaQuery<Project> all = cq.select(projectRoot);
        cq.orderBy(cb.asc(projectRoot.get("title")));
        TypedQuery<Project> allQuery = entityManager.createQuery(all);
        return allQuery.getResultList();
    }
}
