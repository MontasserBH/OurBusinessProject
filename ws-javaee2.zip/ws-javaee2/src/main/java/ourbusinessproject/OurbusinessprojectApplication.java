package ourbusinessproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OurbusinessprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(OurbusinessprojectApplication.class, args);
	}
}
